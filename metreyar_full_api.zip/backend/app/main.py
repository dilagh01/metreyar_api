
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List
from uuid import uuid4

app = FastAPI()

origins = [
    "http://localhost:5000",
    "https://homkar.ir",
    "https://www.homkar.ir"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# مدل‌ها
class Item(BaseModel):
    id: str = None
    name: str
    length: float
    width: float
    height: float
    unit_price: float

class Project(BaseModel):
    id: str = None
    name: str
    items: List[Item] = []

projects = {}

@app.post("/projects")
def create_project(proj: Project):
    proj.id = str(uuid4())
    projects[proj.id] = proj
    return proj

@app.get("/projects")
def list_projects():
    return list(projects.values())

@app.post("/projects/{proj_id}/items")
def add_item(proj_id: str, item: Item):
    item.id = str(uuid4())
    if proj_id in projects:
        projects[proj_id].items.append(item)
        return item
    return {"error": "Project not found"}

@app.get("/projects/{proj_id}/items")
def get_items(proj_id: str):
    if proj_id in projects:
        return projects[proj_id].items
    return {"error": "Project not found"}
